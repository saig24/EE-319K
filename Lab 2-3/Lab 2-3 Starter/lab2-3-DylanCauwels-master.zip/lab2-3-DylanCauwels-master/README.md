## EE319K - Introduction to Embedded Systems - Lab 2

Find the lab description at link below :

https://docs.google.com/document/d/1bPch53jeIG-N8ngwFY4QSMHc90jOngaDXwkYY3XCKr4/edit?usp=sharing
