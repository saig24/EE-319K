## EE319K - Introduction to Embedded Systems - Lab 8

Find the lab description at link below :

https://docs.google.com/document/d/1JarCLIxk93H8fhkWjQr7oXxi3RULE_G211abvzb3DBs/edit?usp=sharing
