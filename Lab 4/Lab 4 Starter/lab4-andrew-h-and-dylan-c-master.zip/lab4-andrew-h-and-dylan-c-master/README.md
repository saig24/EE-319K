## EE319K - Introduction to Embedded Systems - Lab 4

Find the lab description at link below :

https://docs.google.com/document/d/1E6-YN4GSENH78K8xi5OHA0UIGWXyP7X4D_bKAD8684k/edit
