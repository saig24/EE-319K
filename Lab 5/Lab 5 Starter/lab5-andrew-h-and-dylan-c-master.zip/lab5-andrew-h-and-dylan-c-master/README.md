## EE319K - Introduction to Embedded Systems - Lab 5

Find the lab description at link below :

https://docs.google.com/document/d/1MDt8CCzsURqnGKx14CS1Sp-d_kqAHxbYl89t-8SYL1I/edit
