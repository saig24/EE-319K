## EE319K - Introduction to Embedded Systems - Lab 7

Find the lab description at link below :

https://docs.google.com/document/d/1Yg_EJSPmMrWbBpM38iJ2pz13PdFWbmPMixa41JXMnV4/edit?usp=sharing
