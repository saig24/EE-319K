## EE319K - Introduction to Embedded Systems - Lab 6

Find the lab description at link below :

https://docs.google.com/document/d/18nwk_8EsmCZK1w5u5EcbuKxtmBu8BUznT2GJzdtK-CU/edit?usp=sharing
